function check() {
    //用户名长度6-10，只能由数字、字母、下划线组成，首位只能是字母
    var reg = /^[a-zA-Z]\w{5,9}$/;
    var value = document.getElementById("userName").value;
    if (reg.test(value) == false) {
        document.getElementById("error1").innerHTML = "&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;用户名仅支持中英文、数字和下划线，且不能为纯数字";
        document.getElementById("error1").style.color = "#f00";
        document.getElementById("error1").style.fontSize = "10px";
        let re = document.getElementsByClassName("panduan")[0];
        re.className = "error";
    } else {
        return true;
    }

    //手机号码检查
    reg = /^1[3578]\d{9}$/;
    value = document.getElementById("tel").value;
    if (reg.test(value) == false) {
        document.getElementById("error2").innerHTML = "&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;手机号码格式不正确";
        document.getElementById("error2").style.color = "#f00";
        document.getElementById("error2").style.fontSize = "10px";
        let re = document.getElementsByClassName("panduan")[0];
        re.className = "error";
    } else {
        return true;
    }

    //密码长度6-8，至少有一个大写字母，至少有一个小写字母，至少有一个数字，不能包含空格
    reg = /^[a-zA-Z0-9^t]{4,7}$/;
    value = document.getElementById("password").value;
    if (reg.test(value) == false) {
        document.getElementById("error3").innerHTML = "&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;密码设置不符合要求";
        document.getElementById("error3").style.color = "#f00";
        document.getElementById("error3").style.fontSize = "10px";
        let re = document.getElementsByClassName("panduan")[0];
        re.className = "error";
    } else {
        return true;
    }
}